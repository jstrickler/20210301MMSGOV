import sys, re

FILE_SOF = b'\xFF\xD8' # Start bytes
FILE_EOF = b'\xFF\xD9' # End bytes
FILE_EXT = "jpeg" # Desired output extension for above

file_obj=open(sys.argv[1],'rb')
data=file_obj.read()
file_obj.close()

SOF_list=[match.start() for match in re.finditer(re.escape(FILE_SOF),data)]
EOF_list=[match.start() for match in re.finditer(re.escape(FILE_EOF),data)]

i=0
for SOF in SOF_list:
    subdata=data[SOF:EOF_list[i]+2]
    carve_filename="Carve1_"+str(SOF)+"_"+str(EOF_list[i])+"."+FILE_EXT 

    carve_obj=open(carve_filename,'wb')
    carve_obj.write(subdata)
    carve_obj.close()
    i=i+1
    print(("Found a file and carving it to "+carve_filename))